# better-image-browser

https://chrome.google.com/webstore/detail/better-image-browser/kiogkahifhldimpknnnhdiemepmebnhe

a chrome extension to browse image better


![ICON](https://github.com/QS20199/better-image-browser/blob/master/asset/img/icon_128.png)

<div>Icons made by <a href="https://www.flaticon.com/authors/madebyoliver" title="Madebyoliver">Madebyoliver</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/" title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>
